# Part 1
userInput = input ("Enter a Calculation:")


#Part 2
if "=" in str(userInput):
            print("Can't do calculations with an =")
            
        
elif "eval" in str(userInput):
            print("Bad function!")


elif "exec" in str(userInput):
            print("Cant run code in a calculator, sorry")



#part 3
else:
        print(str(eval(userInput)))









# During the challange text bellow this contained functionality for it to
# Work while running as part of a website







